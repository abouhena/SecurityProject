CREATE TABLE IF NOT EXISTS se_project.users
(
    id SERIAL NOT NULL,
    firstname TEXT NOT NULL,
    lastname TEXT NOT NULL,
    email TEXT NOT NULL,
    password TEXT NOT NULL,
    roleid INTEGER NOT NULL,
    CONSTRAINT users_pkey PRIMARY KEY (id)
);

CREATE TABLE IF NOT EXISTS se_project.sessions
(
    id SERIAL NOT NULL,
    userid INTEGER NOT NULL,
    token TEXT NOT NULL,
    expiresat TIMESTAMP NOT NULL,
    CONSTRAINT sessions_pkey PRIMARY KEY (id)
);

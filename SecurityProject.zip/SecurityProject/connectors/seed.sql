-- Insert Roles
INSERT INTO se_project.roles("role")
	VALUES ('user');

UPDATE se_project.users
	SET "roleId"=2
	WHERE "email"='desoukya@gmail.com';
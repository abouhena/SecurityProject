const { isEmpty, subtract } = require("lodash");
const { v4 } = require("uuid");
const bcrypt = require("bcrypt");
const db = require("../../connectors/db");
const roles = require("../../constants/roles");
const { getSessionToken } = require("../../utils/session");
const saltRounds = 10; // The cost factor for bcrypt hashing

const findUserByEmail = async (email) => {
  const user = await db
    .select("*")
    .from("se_project.users")
    .where("email", email)
    .first();
  return user;
};

const getUser = async function (req) {
  const sessionToken = getSessionToken(req);
  if (!sessionToken) {
    return res.status(301).redirect("/");
  }
  const user = await db
    .select("*")
    .from("se_project.sessions")
    .where("token", sessionToken)
    .innerJoin(
      "se_project.users",
      "se_project.sessions.userid",
      "se_project.users.id"
    )
    .innerJoin(
      "se_project.roles",
      "se_project.users.roleid",
      "se_project.roles.id"
    )
    .first();

  user.isNormal = user.roleid === roles.user;
  user.isAdmin = user.roleid === roles.admin;
  user.isSenior = user.roleid === roles.senior;
  return user;
};

module.exports = function (app) {
  app.post("/api/v1/user/register", async function (req, res) {
    // Check if user already exists
    const existingUser = await findUserByEmail(req.body.email);
    if (existingUser) {
      return res.status(400).send("User already exists");
    }

    // Hash the password
    const hashedPassword = await bcrypt.hash(req.body.password, saltRounds);

    // Create new user
    const newUser = {
      // ...other user details...
      email: req.body.email,
      password: hashedPassword,
      roleid: roles.user // assuming default role is 'user'
    };

    try {
      await db("se_project.users").insert(newUser);
      return res.status(201).send("User registered successfully");
    } catch (e) {
      console.log(e.message);
      return res.status(500).send("Error registering user");
    }
  });

  // ...other routes including /api/v1/password/reset...

};

const _ = require("lodash"); // Import lodash
const { v4 } = require("uuid"); // Import v4 from uuid
const db = require("../../connectors/db");
const roles = require("../../constants/roles");
const validator = require("validator");

module.exports = function (app) {
  // Endpoint to create a new user
  const bcrypt = require('bcrypt');

  app.post("/api/v1/user", async function (req, res) {
      // Check if user already exists in the system
      const userExists = await db
        .select("*")
        .from("se_project.users")
        .where("email", req.body.email);
      
      if (!_.isEmpty(userExists)) {
        return res.status(400).send("User already exists");
      }
  
      // Password validation
      const password = req.body.password;
      if (!validator.isStrongPassword(password, {
        minLength: 8, 
        minLowercase: 1, 
        minUppercase: 1, 
        minNumbers: 1, 
        minSymbols: 1 
      })) {
        return res.status(400).send("Password must be strong: at least 8 characters long with a mix of letters, numbers, and symbols");
      }
  
      // Hash the password
      const saltRounds = 10; // You can adjust the salt rounds as needed
      const hashedPassword = await bcrypt.hash(password, saltRounds);
  
      const newUser = {
        firstname: req.body.firstName,
        lastname: req.body.lastName,
        email: req.body.email,
        password: hashedPassword, // Storing the hashed password
        roleid: roles.user,
      };
  
      try {
        const user = await db("se_project.users").insert(newUser).returning("*");
        return res.status(200).json(user);
      } catch (e) {
        console.log(e.message);
        return res.status(400).send("Could not register user");
      }
  });
  
  // Endpoint to handle user login
  app.post("/api/v1/user/login", async function (req, res) {
    const { email, password } = req.body;

    if (!email) {
      return res.status(400).send("Email is required");
    }
    if (!password) {
      return res.status(400).send("Password is required");
    }

    const user = await db
      .select("*")
      .from("se_project.users")
      .where("email", email)
      .first();

    if (_.isEmpty(user)) {
      return res.status(400).send("User does not exist");
    }

    if (user.password !== password) { // Consider using hashed password comparison
      return res.status(401).send("Password does not match");
    }

    const token = v4();
    const currentDateTime = new Date();
    const expiresAt = new Date(currentDateTime.getTime() + 900000); // expire in 15 minutes

    const session = {
      userid: user.id,
      token,
      expiresat: expiresAt,
    };

    try {
      await db("se_project.sessions").insert(session);
      return res
        .cookie("session_token", token, { expires: expiresAt })
        .status(200)
        .send("Login successful");
    } catch (e) {
      console.log(e.message);
      return res.status(400).send("Could not log in user");
    }
  });

  // Additional endpoints and logic can be added here
};
